<?php
error_reporting(0);
if(!file_exists('admin.json')){
$token = readline('Enter Token : ');
$id = readline('Enter Id : ');
$save['info'] = [
'token'=>$token,
'id'=>$id
];
file_put_contents('admin.json',json_encode($save),64|128|256);
}
function save($array){
file_put_contents('admin.json',json_encode($array),64|128|256);
}
$token = json_decode(file_get_contents('admin.json'),true)['info']['token'];
$id = json_decode(file_get_contents('admin.json'),true)['info']['id'];
include 'index.php';
if($id == ""){
echo "Error Id";
}
try {
 $callback = function ($update, $bot) {
  global $id;
  if($update != null){
   if(isset($update->message)){
    $message = $update->message;
    $chat_id = $message->chat->id;   
    $name = $message->from->first_name;
    $message_id = $message->message_id;
    $text = $message->text;
$admin = json_decode(file_get_contents('admin.json'),true);
if($text == '/start'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"*
- Hello $name In Proxy Grabber/Checker Bot .*",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- Grab Proxys .','callback_data'=>'grab'],['text'=>'- Check Proxys .','callback_data'=>'CH']],
]
])
]);
}
}
if(isset($update->callback_query)) {
    $chat_id1 = $update->callback_query->message->chat->id;
    $mid = $update->callback_query->message->message_id;
    $data = $update->callback_query->data;
    $message = $update->message;
    $chat_id = $message->chat->id;
    $text = $message->text;
    $name = $message->from->first_name;
if($data == 'grab'){
bot('editMessageText',[
'chat_id'=>$chat_id1,
'message_id'=>$mid,
'text'=>"*
- Please Pick What Type Of Proxies Do You Want .
- Options : HTTP/S , SOCKS4 , SOCKS5 .*",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- HTTP/S .','callback_data'=>'HT'],['text'=>'- SOCKS4 .','callback_data'=>'S4']],
[['text'=>'- SOCKS5 .','callback_data'=>'S5']],
[['text'=>'- Go Back .','callback_data'=>'back']],
]
])
]);
}
if($data == 'HT'){
system("php HTTP.php");
$HLL = explode("\n",file_get_contents("HTTP/S.txt"));
$HL = count($HLL)-1;
bot('editMessageText',[
'chat_id'=>$chat_id1,
'message_id'=>$mid,
'text'=>"- Done Sir . \n - Grabbed HTTP/S Proxies . \n - Lines : $HL .",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"- Check Them .",'callback_data'=>'HTC']],
[['text'=>"- Go Back .",'callback_data'=>'back']],
]
])
]);
}
if($data == 'S4'){
system("php SOCKS4.php");
$S4LL = explode("\n",file_get_contents("SOCKS4.txt"));
$S4L = count($S4LL)-1;
bot('editMessageText',[
'chat_id'=>$chat_id1,
'message_id'=>$mid,
'text'=>"- Done Sir . \n - Grabbed SOCKS4 Proxies . \n - Lines : $S4L .",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"- Check Them .",'callback_data'=>'S4C']],
[['text'=>"- Go Back .",'callback_data'=>'back']],
]
])
]);
}
if($data == 'S5'){
system("php SOCKS5.php");
$S5LL = explode("\n",file_get_contents("SOCKS5.txt"));
$S4L = count($S5LL)-1;
bot('editMessageText',[
'chat_id'=>$chat_id1,
'message_id'=>$mid,
'text'=>"- Done Sir . \n - Grabbed SOCKS5 Proxies . \n - Lines : $S5L .",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"- Check Them .",'callback_data'=>'S5C']],
[['text'=>"- Go Back .",'callback_data'=>'back']],
]
])
]);
}
if($data == 'CH'){
bot('editMessageText',[
'chat_id'=>$chat_id1,
'message_id'=>$mid,
'text'=>"- Please Sir . \n - Chooes What Type . \n - Of Proxies Do You Want To Check .",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"- HTTP/S .",'callback_data'=>'HTC'],['text'=>"SOCKS4",'callback_data'=>'S4C']],
[['text'=>"- SOCKS5 .",'callback_data'=>'S5C']],
[['text'=>"- Go Back .",'callback_data'=>'back']],
]
])
]);
}
if($data == 'HTC'){
system("screen -dmS HTTP$chat_id1 python3 HTC.py");
$GTT = explode("\n",file_get_contents("GoodHT.txt"));
$GT = count($GTT)-1;
$BTT = explode("\n",file_get_contents("BadHT.txt"));
$BT = count($BTT)-1;
$ETT = explode("\n",file_get_contents("ErrorHT.txt"));
$ET = count($ETT)-1;
bot('editMessageText',[
'chat_id'=>$chat_id1,
'message_id'=>$mid,
'text'=>"- Started Checking HTTP/S Proxies .",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"- Good : $GT .",'callback_data'=>'UPDHT'],['text'=>"- Bad : $BT .",'callback_data'=>'UPDHT']],
[['text'=>"- Error : $ET .",'callback_data'=>'UPDHT']],
[['text'=>"- Stop .",'callback_data'=>'STPHT']],
]
])
]);
}
if($data == 'UPDHT'){
$GTT = explode("\n",file_get_contents("GoodHT.txt"));
$GT = count($GTT)-1;
$BTT = explode("\n",file_get_contents("BadHT.txt"));
$BT = count($BTT)-1;
$ETT = explode("\n",file_get_contents("ErrorHT.txt"));
$ET = count($ETT)-1;
bot('editMessageText',[
'chat_id'=>$chat_id1,
'message_id'=>$mid,
'text'=>"- Updating States Checking HTTP/S Proxies .",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"- Good : $GT .",'callback_data'=>'UPDHT'],['text'=>"- Bad : $BT.",'callback_data'=>'UPDHT']],
[['text'=>"- Error : $ET .",'callback_data'=>'UPDHT']],
[['text'=>"- Stop .",'callback_data'=>'STPHT']],
]
])
]);
}
if($data == 'STPHT'){
$GTT = explode("\n",file_get_contents("GoodHT.txt"));
$GT = count($GTT)-1;
$BTT = explode("\n",file_get_contents("BadHT.txt"));
$BT = count($BTT)-1;
$ETT = explode("\n",file_get_contents("ErrorHT.txt"));
$ET = count($ETT)-1;
system("screen -S HTTP$chat_id1 -X kill");
bot('editMessageText',[
'chat_id'=>$chat_id1,
'message_id'=>$mid,
'text'=>"- Done Stopped Checking . \n - Good : $GT . \n - Bad : $BT . \n - Error : $ET .",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"- Send The File .",'callback_data'=>'SEHT']],
[['text'=>"- Go Back .",'callback_data'=>'back']],
]
])
]);
}
if($data == 'SEHT'){
$GTT = explode("\n",file_get_contents("GoodHT.txt"));
$GT = count($GTT)-1;
bot('Senddocument',[
'chat_id'=>$chat_id1,
'document' =>new CURLFile('GoodHT.txt'),
'caption'=>"- Here Is Your HTTP/S Proxys . \n - Lines : $GT .",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"- DEV .",'url'=>'t.me/C_Y_L']],
]
])
]);
}
}if($data == 'S4C'){
system("screen -dmS SOCKS4$chat_id1 python3 S4C.py");
$GoodS4 = explode("\n",file_get_contents("GoodS4.txt"));
$G4 = count($GoodS4)-1;
$Bads4 = explode("\n",file_get_contents("BadS4.txt"));
$B4 = count($Bads4)-1;
$ErrorS4 = explode("\n",file_get_contents("ErrorS4.txt"));
$E4 = count($ErrorS4)-1;
bot('editMessageText',[
'chat_id'=>$chat_id1,
'message_id'=>$mid,
'text'=>"- Started Checking SOCKS4 Proxies .",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"- Good : $G4 .",'callback_data'=>'UPDS4'],['text'=>"- Bad : $B4 .",'callback_data'=>'UPDS4']],
[['text'=>"- Error : $E4 .",'callback_data'=>'UPDS4']],
[['text'=>"- Stop .",'callback_data'=>'STPS4']],
]
])
]);
}
if($data == 'UPDS4'){
$GoodS4 = explode("\n",file_get_contents("GoodS4.txt"));
$G4 = count($GoodS4)-1;
$Bads4 = explode("\n",file_get_contents("BadS4.txt"));
$B4 = count($Bads4)-1;
$ErrorS4 = explode("\n",file_get_contents("ErrorS4.txt"));
$E4 = count($ErrorS4)-1;
bot('editMessageText',[
'chat_id'=>$chat_id1,
'message_id'=>$mid,
'text'=>"- Updating States Checking SOCKS4 Proxies .",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"- Good : $G4 .",'callback_data'=>'UPDS4'],['text'=>"- Bad : $B4.",'callback_data'=>'UPDS4']],
[['text'=>"- Error : $E4 .",'callback_data'=>'UPDS4']],
[['text'=>"- Stop .",'callback_data'=>'STPS4']],
]
])
]);
}
if($data == 'STPS4'){
$GoodS4 = explode("\n",file_get_contents("GoodS4.txt"));
$G4 = count($GoodS4)-1;
$Bads4 = explode("\n",file_get_contents("BadS4.txt"));
$B4 = count($Bads4)-1;
$ErrorS4 = explode("\n",file_get_contents("ErrorS4.txt"));
$E4 = count($ErrorS4)-1;
system("screen -S SOCKS4$chat_id1 -X kill");
bot('editMessageText',[
'chat_id'=>$chat_id1,
'message_id'=>$mid,
'text'=>"- Done Stopped Checking . \n - Good : $G4 . \n - Bad : $B4 . \n - Error : $E4 .",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"- Send The File .",'callback_data'=>'SE4']],
[['text'=>"- Go Back .",'callback_data'=>'back']],
]
])
]);
}
if($data == 'SE4'){
$GoodS4 = explode("\n",file_get_contents("GoodS4.txt"));
$G4 = count($GoodS4)-1;
bot('Senddocument',[
'chat_id'=>$chat_id1,
'document' =>new CURLFile('GoodS4.txt'),
'caption'=>"- Here Is Your SOCKS4 Proxys . \n - Lines : $G4 .",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"- DEV .",'url'=>'t.me/C_Y_L']],
]
])
]);
}
if($data == 'S5C'){
system("screen -dmS SOCKS5$chat_id1 python3 S5C.py");
$GoodS5 = explode("\n",file_get_contents("GoodS5.txt"));
$G5 = count($GoodS5)-1;
$BadS5 = explode("\n",file_get_contents("BadS5.txt"));
$B5 = count($BadS5)-1;
$ErrorS5 = explode("\n",file_get_contents("ErrorS5.txt"));
$E5 = count($ErrorS5)-1;
bot('editMessageText',[
'chat_id'=>$chat_id1,
'message_id'=>$mid,
'text'=>"- Started Checking SOCKS5 Proxies .",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"- Good : $G5 .",'callback_data'=>'UPDS5'],['text'=>"- Bad : $B5 .",'callback_data'=>'UPDS5']],
[['text'=>"- Error : $E5 .",'callback_data'=>'UPDS5']],
[['text'=>"- Stop .",'callback_data'=>'STPS5']],
]
])
]);
}
if($data == 'UPDS5'){
$GoodS5 = explode("\n",file_get_contents("GoodS5.txt"));
$G5 = count($GoodS5)-1;
$BadS5 = explode("\n",file_get_contents("BadS5.txt"));
$B5 = count($BadS5)-1;
$ErrorS5 = explode("\n",file_get_contents("ErrorS5.txt"));
$E5 = count($ErrorS5)-1;
bot('editMessageText',[
'chat_id'=>$chat_id1,
'message_id'=>$mid,
'text'=>"- Updating States Checking SOCKS5 Proxies .",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"- Good : $G5 .",'callback_data'=>'UPDS5'],['text'=>"- Bad : $B5 .",'callback_data'=>'UPDS5']],
[['text'=>"- Error : $E5 .",'callback_data'=>'UPDS5']],
[['text'=>"- Stop .",'callback_data'=>'STPS5']],
]
])
]);
}
if($data == 'STPS5'){
$GoodS5 = explode("\n",file_get_contents("GoodS5.txt"));
$G5 = count($GoodS5)-1;
$BadS5 = explode("\n",file_get_contents("BadS5.txt"));
$B5 = count($BadS5)-1;
$ErrorS5 = explode("\n",file_get_contents("ErrorS5.txt"));
$E5 = count($ErrorS5)-1;
system("screen -S SOCKS5$chat_id1 -X kill");
bot('editMessageText',[
'chat_id'=>$chat_id1,
'message_id'=>$mid,
'text'=>"- Done Stopped Checking . \n - Good : $G5 . \n - Bad : $B5 . \n - Error : $E5 .",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"- Send The File .",'callback_data'=>'SE5']],
[['text'=>"- Go Back .",'callback_data'=>'back']],
]
])
]);
}
if($data == 'SE5'){
$GoodS5 = explode("\n",file_get_contents("GoodS5.txt"));
$G5 = count($GoodS5)-1;
bot('Senddocument',[
'chat_id'=>$chat_id1,
'document' =>new CURLFile('GoodS5.txt'),
'caption'=>"- Here Is Your SOCKS5 Proxys . \n - Lines : $G5 .",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"- DEV .",'url'=>'t.me/C_Y_L']],
]
])
]);
}
if($data == 'back'){
bot('editMessageText',[
'chat_id'=>$chat_id1,
'message_id'=>$mid,
'text'=>"*
- Hello $name In Proxy Grabber/Checker Bot .*",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- Grab Proxys .','callback_data'=>'grab'],['text'=>'- Check Proxys .','callback_data'=>'CH']],
]
])
]);
}
}
    };
         $bot = new EzTG(array('throw_telegram_errors'=>true,'token' => $token, 'callback' => $callback));
  }
    catch(Exception $e){
 echo $e->getMessage().PHP_EOL;
 sleep(1);
}
