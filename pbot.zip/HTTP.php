<?php
$vv = file_get_contents("https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all");
$ss = file_put_contents("HTTP.txt","$vv");
