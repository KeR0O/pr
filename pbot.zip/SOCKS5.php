<?php
$vv = file_get_contents("https://api.proxyscrape.com/v2/?request=getproxies&protocol=socks5&timeout=10000&country=all");
$ss = file_put_contents("SOCKS5.txt","$vv");