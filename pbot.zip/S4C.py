import random, requests, threading, queue
from colorama import Fore, Style
from time import sleep

try:
    os.system('cls' if os.name == 'nt' else 'clear')
    os.system('color')
except:
    pass

r   = requests.Session()
q   = queue.Queue()
good = 0
bad = 0
error = 0

url = 'https://google.com'
def check(prox):
    global url,r,q
    r.proxies = {'http':'http://{}','https':'http://{}'.format(prox,prox)}
    try:
        req = r.get(url,timeout=5)
        if req.status_code == 200:
            print(Fore.GREEN+"[+] Good : {}".format(prox))
            with open('GoodS4.txt','a') as goodP:
                goodP.write(prox+'\n')
        else:
            print(Fore.RED +"[-] Bad : {}".format(prox))
            with open('BadS4.txt','a') as bad:
                bad.write(prox+'\n')
    except:
        print(Fore.RED +"[-] Erorr : {}".format(prox))
        with open('ErrorS4.txt','a') as error:
                error.write(prox+'\n')

Style.RESET_ALL

for proxy in open('SOCKS4.txt','r').read().splitlines():
	q.put(proxy)

def start():
    while True:
        q_str = str(q.get())
        check(q_str)


prox_list = []
for i in range(25):
    t = threading.Thread(target=start)
    t.start()
    prox_list.append(t)
for i in prox_list:
    i.join()

